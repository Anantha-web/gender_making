# telugu_nouns

Telugu nouns for Gender marking 
